import copy

# Exercise 1
def shepherd_on_island(island):
    """
    On this function it is checked if shepherd is on island
    if shepherd is on island returns True otherwise False
    """
    if "Shp" in island:
        return True
    return False

def objects_on_island(objects, mainland):
    """
    On this function we check which objects are on island when objects on mainland are known.
    Deletes all objects from objects list that are on mainland
    """
    return [obj for obj in objects if obj not in mainland]

def permited_state(objects, mainland):
    """
    On this function it is checked if the planned move is allowed on both mainland and on island
    if move is not allowed function returns False and if move is allowed returns True
    """
    
    island = objects_on_island(objects, mainland)
    # if shepherd is on island, (wolf and sheep) or (sheep and cabbage) can't be on mainland
    if shepherd_on_island(island):
        if ("W" in mainland and "S" in mainland) or ("S" in mainland and "C" in mainland):
            return False
        return True
    # Using same rules as above but this time shepherd is on mainland
    else:
        if ("W" in island and "S" in island) or ("S" in island and "C" in island):
            return False
        return True
    
def generate_new_permited_mainlands(objects, mainland):
    "This function will generate new permited states for mainland"
    mainland = copy.deepcopy(mainland)
    new_mainlands = [] # initialize new_mainlands list
    island = objects_on_island(objects, mainland)   
    if shepherd_on_island(island):
        island.remove("Shp") # atleast shepherd is moving out of island
        mainland.append("Shp")
        if permited_state(objects, mainland):
            new_mainlands.append(sorted(mainland))
        for obj in island:
            mainland_tmp = mainland + [obj]
            if permited_state(objects, mainland_tmp):
                new_mainlands.append(sorted(mainland_tmp))
                
    else:
        mainland.remove("Shp") # Atleast shepherd leaves mainland
        island.append("Shp")
        if permited_state(objects, mainland):
            new_mainlands.append(sorted(mainland))
        mainland_tmp = copy.deepcopy(mainland)
        for obj in mainland:
            mainland_tmp.remove(obj)
            if permited_state(objects, mainland_tmp):
                new_mainlands.append(sorted(mainland_tmp))
            mainland_tmp.append(obj)
    return new_mainlands

def print_moves(objects, path):
    """
    This function prints complete path once path is found.
    """
    print('    Mainland' + ' '*23 + 'Boat' +' '*28 + 'Island')
    for i, mainland in enumerate(path):
        island = objects_on_island(objects, mainland)
        if shepherd_on_island(island):
            print('     {}'.format(mainland) + ' '*(61-len(str(mainland))) + '{}'.format(island))
            if i<len(path)-1:
                boat = [x for x in island if x not in objects_on_island(objects, path[i+1])]
                print('{}.   '.format(i+1) + ' '*27 + '<-{}'.format(boat))
        else:
            print('     {}'.format(mainland) + ' '*(61-len(str(mainland))) + '{}'.format(island))
            if i<len(path)-1:
                boat = [x for x in mainland if x not in path[i+1]]
                print('{}.   '.format(i+1) + ' '*29 + '{}->'.format(boat))

# Exercise 2
def print_state(state):
    """
    Creates printable game table
    """
    
    printout = ""
    printout += "+---+---+---+\n"
    for i in range(3):
        for j in range(3):
            tile = state[i*3+j]
            printout += "| {} ".format(" " if tile == 0 else tile)
        printout += "|\n"
        printout += "+---+---+---+\n"
    return printout

def solve_permited_moves(location):
    """
    This function solves moves for empty tile
    """
    
    moves = [1, -1, 3, -3]
    permited_moves = []
    for move in moves:
        if 0 <= location + move < 9:
            if move == 1 and (location == 2 or location == 5 or location == 8):
                continue
            
            if move == -1 and (location == 0 or location == 3 or location == 6):
                continue
                
            permited_moves.append(move)
    return permited_moves

def generate_new_permited_states(state):
    empty_tile = state.index(0) # empty tile
    permited_moves = solve_permited_moves(empty_tile)
    new_states = []
    
    for move in permited_moves:
        new_state = copy.deepcopy(state)
        (new_state[empty_tile + move], new_state[empty_tile]) = (new_state[empty_tile], new_state[empty_tile + move])
        new_states.append(new_state)
    return new_states

def sort_open_list(open_list, f_scores):
    f_scores_tmp = []
    for state, path in open_list:
        f_scores_tmp.append(f_scores[string(state)])
    return [x for y, x in sorted(zip(f_scores_tmp, open_list))]

def string(list_of_strings):
    """Converts list of strings in to string"""
    return "".join(list(map(str, list_of_strings)))